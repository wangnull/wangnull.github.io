# Simpleyyt

My blog based on Jekyll-Bootstrap.

## About Jekyll-Bootstrap

For all usage and documentation please see: <http://jekyllbootstrap.com>

## About theme

This theme is the copy of [elementaryOS](http://elementaryos.org) portal page. Some features are imperfect, but I will make it more perfect.

## Usage

You can edit the `_config.yml` file to change the setting of site. If you want to change avatar or favicon, just replace the files in `assets\themes\Snail\img`.

## Change Log

 * Add google custom search engine.

## License

[MIT](http://opensource.org/licenses/MIT)
